char* encode_cat(char* vvod_cat, char* encode_vvod_cat, int len_message);
char* decode_cat(char* encode_vvod_cat, char* decode_vvod_cat, int len_message);
void KOSHAK(char* vivod, int len_message, char probel_char);